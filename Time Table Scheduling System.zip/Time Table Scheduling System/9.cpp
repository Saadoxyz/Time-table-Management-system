#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include <cstdlib>
#include <sstream>
#include <stdexcept> // For runtime_error
#include <limits> 
using namespace std;

#define Section 3
#define Day 5
#define Slot 3

string TimeTable[Section][Day][Slot];
string Teacher[Section][Day][Slot];
string Roomno[Section][Day][Slot];

struct Node {
    string T_Name;
    string Subject;
    int Room_no;
    bool HasLab;
    int CreditHour;
    int OriginalCreditHour;
    Node* next;
};

Node* head = nullptr;

// Function to create a new node
Node* createNode(const string& t_name, const string& subject, int room_no, bool hasLab, int creditHour) {
    Node* newNode = new Node;
    newNode->T_Name = t_name;
    newNode->Subject = subject;
    newNode->Room_no = room_no;
    newNode->HasLab = hasLab;
    newNode->CreditHour = creditHour;
    newNode->OriginalCreditHour = creditHour;
    newNode->next = newNode; // Point to itself initially
    return newNode;
}

// Function to add a node to the circular linked list
void addNode(Node* newNode) {
    if (!head) {
        head = newNode;
    } else {
        Node* temp = head;
        while (temp->next != head) {
            temp = temp->next;
        }
        temp->next = newNode;
        newNode->next = head;
    }
}

// Function to load data from a file into the circular linked list


void loadDataFromCSV(const string& fileName) {
     try {
    ifstream file(fileName);
    if (!file.is_open()) {
        cout << "Error opening file: " << fileName << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        string t_name, subject, hasLabStr;
        int room_no, creditHour;
        bool hasLab;

        // Parse the CSV line
        if (getline(ss, t_name, ',') &&
            getline(ss, subject, ',') &&
            ss >> room_no &&
            ss.ignore() && // Skip comma
            getline(ss, hasLabStr, ',') &&
            ss >> creditHour) {
            
            hasLab = (hasLabStr == "true"); // Convert string to boolean
            Node* newNode = createNode(t_name, subject, room_no, hasLab, creditHour);
            addNode(newNode);
        } else {
            cout << "Error parsing line: " << line << endl;
        }
    }
     file.close();
        cout << "Data loaded successfully from " << fileName << ".\n";
    } catch (const runtime_error& e) {
        cout << "Error: " << e.what() << endl;
    }
}



// Function to display the circular linked list
void displayCircularList() {
    if (!head) {
        cout << "The list is empty." << endl;
        return;
    }

    Node* temp = head;
    cout << "Circular Linked List Subjects: ";
    do {
        cout << temp->Subject << " -> ";
        temp = temp->next;
    } while (temp != head);
    cout << "HEAD" << endl; // Indicate the circular nature of the list
}

// Function to shuffle the circular linked list (without vector)
void shuffleCircularList() {
    if (!head || head->next == head) return; // No need to shuffle for single-node or empty list

    // Fisher-Yates shuffle on the circular linked list
    Node* temp = head;
    int size = 0;

    // Calculate the size of the list
    do {
        size++;
        temp = temp->next;
    } while (temp != head);

    srand(time(0));
    for (int i = size - 1; i > 0; --i) {
        int j = rand() % (i + 1);

        // Traverse to the ith and jth nodes in the list
        Node* ith = head;
        Node* jth = head;

        for (int k = 0; k < i; ++k) {
            ith = ith->next;
        }
        for (int k = 0; k < j; ++k) {
            jth = jth->next;
        }

        // Swap the data of ith and jth nodes
        swap(ith->T_Name, jth->T_Name);
        swap(ith->Subject, jth->Subject);
        swap(ith->Room_no, jth->Room_no);
        swap(ith->HasLab, jth->HasLab);
        swap(ith->CreditHour, jth->CreditHour);
        swap(ith->OriginalCreditHour, jth->OriginalCreditHour);
    }
}

// Function to refresh the circular linked list (remove all nodes and reload data)
void refreshCircularList(const string& fileName) {
    if (!head) return;

    Node* temp = head;
    Node* nextNode;

    // Properly unlink and delete all nodes
    do {
        nextNode = temp->next;
        delete temp;
        temp = nextNode;
    } while (temp != head);
    head = nullptr;

    // Reload data from the file
    loadDataFromCSV(fileName);
}

// Helper function to check if a slot is empty
bool SlotIsEmpty(string arr[Section][Day][Slot], int sec, int day, int slot) {
    return arr[sec][day][slot].empty();
}

// Helper function to check if a slot is available for a subject
bool isSlotAvailable(const string& subject, int day, int slot) {
    for (int l = 0; l < Section; l++) {
        if (TimeTable[l][day][slot] == subject) {
            return false;
        }
    }
    return true;
}
void saveTimetableToFile(const string& filename) {
    try {
    ofstream outFile(filename);

    if (!outFile) {
        cout << "Error opening file for writing." << endl;
        return;
    }

    for (int sec = 0; sec < Section; sec++) {
        outFile << "Section " << static_cast<char>('A' + sec) << endl;
        for (int day = 0; day < Day; day++) {
            outFile << "Day " << day + 1 << ": ";
            for (int slot = 0; slot < Slot; slot++) {
                if (TimeTable[sec][day][slot].empty()) {
                    outFile << "Free ";
                } else {
                    outFile << TimeTable[sec][day][slot] << " ";
                }
            }
            outFile << endl;
        }

        outFile << endl; // Separate sections
    }

    outFile.close();
    cout << "Timetable successfully saved to " << filename << endl;
     }catch (const runtime_error& e) {
        cout << "Error: " << e.what() << endl;
    }
}

// Function to auto-adjust the timetable based on the circular linked list
void auto_adjust(const string& filename) {
    if (!head) {
        cout << "No data to adjust in timetable." << endl;
        return;
    }

    shuffleCircularList(); // Randomize the list for fairness

    for (int i = 0; i < Section; i++) {
        Node* current = head;
        bool allSubjectsPlaced = false; // Track if all subjects are placed

        while (!allSubjectsPlaced) {
            allSubjectsPlaced = true; // Assume all subjects are placed initially

            do {
                if (current->CreditHour > 0) {
                    allSubjectsPlaced = false; // Found a subject that still needs to be placed

                    int weeklylimit = 1;
                    for (int j = 0; j < Day; j++) {
                        int daylimit = 3;
                        bool todaylabsheduled = false; // Track if a lab is already scheduled for the day
                        for (int k = 0; k < Slot; k++) {
                            if (SlotIsEmpty(TimeTable, i, j, k) && isSlotAvailable(current->Subject, j, k)) {
                                bool slotConflict = false;
                                for (int l = 0; l < Section; l++) {
                                    if (TimeTable[l][j][k] == current->Subject) {
                                        slotConflict = true;
                                        break;
                                    }
                                }
                                if (!slotConflict) {
                                    if (current->HasLab && !todaylabsheduled && k == 0) {
                                        TimeTable[i][j][k] = current->Subject;
                                        Teacher[i][j][k] = current->T_Name;
                                        Roomno[i][j][k] = to_string(current->Room_no);
                                        current->CreditHour--;
                                        todaylabsheduled = true;
                                        daylimit -= 2;
                                        break;
                                    } else if (k == 2 && weeklylimit > 0 && current->HasLab && !todaylabsheduled) {
                                        TimeTable[i][j][k] = current->Subject;
                                        Teacher[i][j][k] = current->T_Name;
                                        Roomno[i][j][k] = to_string(current->Room_no);
                                        current->CreditHour--;
                                        weeklylimit--;
                                        todaylabsheduled = true;
                                        daylimit--;
                                        break;
                                    } else if (!current->HasLab) {
                                        TimeTable[i][j][k] = current->Subject;
                                        Teacher[i][j][k] = current->T_Name;
                                        Roomno[i][j][k] = to_string(current->Room_no);
                                        current->CreditHour--;
                                        daylimit--;
                                        break;
                                    }
                                }
                            }
                        }
                      //  if (todaylabsheduled) break; // Exit if a lab is scheduled for the day
                        if (current->CreditHour == 0) break; // Exit if the subject is fully placed
                    }
                }
                current = current->next;
            } while (current != head);
        }

        // Restore the credit hours for the next section
        current = head;
        do {
            current->CreditHour = current->OriginalCreditHour;
            current = current->next;
        } while (current != head);
    }
    saveTimetableToFile(filename);
}
// Function to search and display a teacher's timetable
void searchAndDisplayTeacherTimeTable(const string& teacherName) {
    bool found = false;
    
    // Iterate over all sections, days, and slots to find the teacher
    for (int i = 0; i < Section; i++) {
        cout << "\nSection " << i + 1 << ":\n";
        for (int j = 0; j < Day; j++) {
            for (int k = 0; k < Slot; k++) {
                if (Teacher[i][j][k] == teacherName) {
                    found = true;
                    cout << "  Day " << j + 1 << ", Slot " << k + 1 << ": " 
                         << TimeTable[i][j][k] << " (" 
                         << Roomno[i][j][k] << ")\n";
                }
            }
        }
    }

    if (!found) {
        cout << "No timetable found for teacher: " << teacherName << endl;
    }
}
// Function to print the timetable
void printTimeTable() {
    for (int i = 0; i < Section; i++) {
        cout << "Section " << i + 1 << ":\n";
        for (int j = 0; j < Day; j++) {
            cout << "  Day " << j + 1 << ": ";
            for (int k = 0; k < Slot; k++) {
                if (TimeTable[i][j][k].empty()) {
                    cout << "Empty |";
                } else {
                    cout << TimeTable[i][j][k] << " ";
                    cout << Teacher[i][j][k] << " ";
                    cout << Roomno[i][j][k] << " |";
                }
            }
            cout << endl;
        }
        cout << endl;
    }
}
// Function to edit or update the timetable
void updateTimeTable() {
    try {
        int section, day, slot;
        string subject, teacher, room;

        // Get valid input for section, day, and slot
        while (true) {
            cout << "Enter Section (1 to 3): ";
            cin >> section;
            if (cin.fail() || section < 1 || section > 3) {
                cin.clear(); // Clear the error flag
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
                cout << "Invalid section number. Please enter a number between 1 and 3." << endl;
                continue;
            }
            break;
        }

        while (true) {
            cout << "Enter Day (1 to 5): ";
            cin >> day;
            if (cin.fail() || day < 1 || day > 5) {
                cin.clear(); // Clear the error flag
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
                cout << "Invalid day number. Please enter a number between 1 and 5." << endl;
                continue;
            }
            break;
        }

        while (true) {
            cout << "Enter Slot (1 to 3): ";
            cin >> slot;
            if (cin.fail() || slot < 1 || slot > 3) {
                cin.clear(); // Clear the error flag
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
                cout << "Invalid slot number. Please enter a number between 1 and 3." << endl;
                continue;
            }
            break;
        }

        // Adjust indices to be zero-based
        section -= 1;
        day -= 1;
        slot -= 1;

        // Get valid input for subject, teacher, and room
        cout << "Enter new subject: ";
        cin.ignore(); // Clear any leftover newline character
        getline(cin, subject);
        if (subject.empty()) {
            throw runtime_error("Subject cannot be empty.");
        }

        cout << "Enter new teacher: ";
        getline(cin, teacher);
        if (teacher.empty()) {
            throw runtime_error("Teacher name cannot be empty.");
        }

        cout << "Enter new room number: ";
        getline(cin, room);
        if (room.empty()) {
            throw runtime_error("Room number cannot be empty.");
        }

        // Update the timetable
        TimeTable[section][day][slot] = subject;
        Teacher[section][day][slot] = teacher;
        Roomno[section][day][slot] = room;

        cout << "Timetable updated successfully!" << endl;
        printTimeTable();

    } catch (const runtime_error& e) {
        cout << "Error: " << e.what() << endl;
    }
}
int main() {
    string fileName = "timetable2.csv";
    int choice;
    
    try {
        do {
            cout << "Menu:\n";
            cout << "1. Load Data\n";
            cout << "2. Display Data\n";
            cout << "3. Search and Display Teacher's Timetable\n";
            cout << "4. Update Timetable\n";
            cout << "5. Auto Adjust Timetable\n";
            cout << "6. Refresh Data\n";
            cout << "7. Exit\n";
            cout << "Enter your choice: ";
            
            if (!(cin >> choice)) { // Check for non-integer input
                cin.clear(); // Clear the error flag
                cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Discard invalid input
                cout << "Invalid choice. Please enter a number between 1 and 7.\n";
                choice = 0; // Set choice to a value that won't break the loop
                continue;
            }

            if (choice < 1 || choice > 7) { // Check if choice is out of range
                cout << "Invalid choice. Please select a valid option between 1 and 7.\n";
                continue;
            }

            switch (choice) {
                case 1:
                    loadDataFromCSV(fileName);
                    cout << "Data loaded successfully.\n";
                    break;
                case 2:
                    cout << "Circular Linked List Data:\n";
                    displayCircularList();
                    cout << "Timetable:\n";
                    printTimeTable();
                    break;
                case 3: {
                    string teacherName;
                    cout << "Enter the teacher's name to search: ";
                    cin.ignore();
                    getline(cin, teacherName);
                    searchAndDisplayTeacherTimeTable(teacherName);
                    break;
                }
                case 4:
                    updateTimeTable();
                    break;
                case 5:
                    auto_adjust("output_timetable.csv");
                    cout << "Timetable adjusted successfully.\n";
                    break;
                case 6:
                    refreshCircularList(fileName);
                    cout << "Data refreshed successfully.\n";
                    break;
                case 7:
                    cout << "Exiting...\n";
                    break;
                default:
                    cout << "Invalid choice. Please try again.\n";
            }
        } while (choice != 7); // Changed loop to continue until 7 is selected
    } catch (const runtime_error& e) {
        cout << "Unexpected Error: " << e.what() << endl;
    }

    return 0;
}